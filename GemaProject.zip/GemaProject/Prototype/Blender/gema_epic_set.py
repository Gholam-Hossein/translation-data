import bpy
import math
import os
from mathutils import Vector

# Gema EPIC set — hero + enemy + hill + walls, stylized-detailed but mobile friendly.
# Run: blender --background --python gema_epic_set.py
OUT_DIR = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else bpy.path.abspath("//")
def out(name): return os.path.join(OUT_DIR, name)

def make_mat(name, color, metallic=0.0, roughness=0.5):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        if "Base Color" in bsdf.inputs:
            bsdf.inputs["Base Color"].default_value = (*color, 1.0)
        if "Metallic" in bsdf.inputs:
            bsdf.inputs["Metallic"].default_value = metallic
        if "Roughness" in bsdf.inputs:
            bsdf.inputs["Roughness"].default_value = roughness
    m.diffuse_color = (*color, 1.0)
    m.metallic = metallic
    m.roughness = roughness
    return m

SKIN = make_mat("Epic_Skin", (0.92, 0.55, 0.36), 0, .45)
SKIN_SH = make_mat("Epic_Skin_Shadow", (0.78, 0.38, 0.22), 0, .55)
HAIR = make_mat("Epic_Hair", (0.28, 0.09, 0.02), 0, .6)
HAIR_HI = make_mat("Epic_Hair_Hi", (0.48, 0.18, 0.04), 0, .5)
ARMOR = make_mat("Epic_Armor", (0.62, 0.72, 0.84), .85, .22)
ARMOR_L = make_mat("Epic_Armor_L", (0.85, 0.92, 0.98), .7, .18)
ARMOR_D = make_mat("Epic_Armor_D", (0.10, 0.16, 0.26), .75, .25)
BLUE = make_mat("Epic_Blue", (0.07, 0.22, 0.62), .1, .35)
BLUE_L = make_mat("Epic_Blue_L", (0.15, 0.45, 0.95), .15, .3)
GOLD = make_mat("Epic_Gold", (0.98, 0.60, 0.10), .85, .2)
LEATHER = make_mat("Epic_Leather", (0.30, 0.11, 0.03), 0, .7)
WOOD = make_mat("Epic_Wood", (0.42, 0.16, 0.04), 0, .6)
STEEL = make_mat("Epic_Steel", (0.70, 0.82, 0.94), .9, .15)
EYE_W = make_mat("Epic_EyeW", (0.99, 0.99, 0.98), 0, .15)
EYE_D = make_mat("Epic_EyeD", (0.02, 0.08, 0.16), .2, .1)
GEM = make_mat("Epic_Gem", (0.10, 0.90, 0.98), .4, .12)
ENEMY = make_mat("Epic_Enemy", (0.90, 0.91, 0.87), 0, .55)
ENEMY_D = make_mat("Epic_Enemy_D", (0.72, 0.74, 0.70), 0, .65)
ENEMY_CLAW = make_mat("Epic_Claw", (0.82, 0.83, 0.80), .3, .35)
HILL = make_mat("Epic_Hill", (0.20, 0.55, 0.18), 0, .7)
HILL_D = make_mat("Epic_Hill_D", (0.12, 0.38, 0.12), 0, .75)
WALLM = make_mat("Epic_Wall", (0.94, 0.86, 0.90), 0, .5)
WALL_CAP = make_mat("Epic_WallCap", (0.45, 0.62, 0.92), .1, .4)
ROCK = make_mat("Epic_Rock", (0.45, 0.47, 0.50), 0, .8)
GRASS = make_mat("Epic_Grass", (0.28, 0.68, 0.22), 0, .6)

def smooth(o):
    if hasattr(o.data, "polygons"):
        for p in o.data.polygons: p.use_smooth = True
    return o
def bevel(o, w=.03, s=3):
    m = o.modifiers.new("Soft", "BEVEL"); m.width = w; m.segments = s
    return o
def cube(n, loc, sc, mat, rot=(0,0,0), edge=.03, parent=None):
    bpy.ops.mesh.primitive_cube_add(location=loc, rotation=rot)
    o = bpy.context.object; o.name = n; o.scale = sc
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    if edge: bevel(o, edge, 3)
    smooth(o); o.data.materials.append(mat)
    if parent: o.parent = parent
    return o
def sphere(n, loc, sc, mat, parent=None, seg=24, ring=16):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=seg, ring_count=ring, location=loc)
    o = bpy.context.object; o.name = n; o.scale = sc
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    smooth(o); o.data.materials.append(mat)
    if parent: o.parent = parent
    return o
def ico(n, loc, sc, mat, parent=None, subd=2):
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=subd, radius=1, location=loc)
    o = bpy.context.object; o.name = n; o.scale = sc
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    smooth(o); o.data.materials.append(mat)
    if parent: o.parent = parent
    return o
def cyl(n, loc, r, d, mat, rot=(0,0,0), parent=None, v=16):
    bpy.ops.mesh.primitive_cylinder_add(vertices=v, radius=r, depth=d, location=loc, rotation=rot)
    o = bpy.context.object; o.name = n; o.data.materials.append(mat); smooth(o); bevel(o, .015, 2)
    if parent: o.parent = parent
    return o
def cone(n, loc, r1, r2, d, mat, rot=(0,0,0), parent=None, v=12):
    bpy.ops.mesh.primitive_cone_add(vertices=v, radius1=r1, radius2=r2, depth=d, location=loc, rotation=rot)
    o = bpy.context.object; o.name = n; o.data.materials.append(mat); smooth(o); bevel(o, .012, 2)
    if parent: o.parent = parent
    return o
def torus(n, loc, ma, mi, mat, rot=(0,0,0), parent=None):
    bpy.ops.mesh.primitive_torus_add(major_radius=ma, minor_radius=mi, major_segments=28, minor_segments=10, location=loc, rotation=rot)
    o = bpy.context.object; o.name = n; o.data.materials.append(mat); smooth(o)
    if parent: o.parent = parent
    return o
def between(n, a, b, r, mat, parent=None, v=12):
    a = Vector(a); b = Vector(b); d = b - a
    o = cyl(n, (a + b) / 2, r, d.length, mat, parent=parent, v=v)
    o.rotation_euler = d.to_track_quat("Z", "Y").to_euler()
    return o
def plate(n, outline, thick, mat, loc=(0,0,0), edge=.025, parent=None):
    k = len(outline); verts = []
    for x, z in outline: verts.append((x, -thick/2, z))
    for x, z in outline: verts.append((x, thick/2, z))
    faces = [tuple(range(k-1, -1, -1)), tuple(range(k, 2*k))]
    for i in range(k):
        j = (i+1) % k; faces.append((i, j, k+j, k+i))
    me = bpy.data.meshes.new(n+"_M"); me.from_pydata(verts, [], faces); me.update()
    o = bpy.data.objects.new(n, me); bpy.context.collection.objects.link(o); o.location = loc
    o.data.materials.append(mat); bevel(o, edge, 3); smooth(o)
    if parent: o.parent = parent
    return o
def star(r, inner, pts=5, rot=math.pi/2):
    o = []
    for i in range(pts*2):
        a = rot + i*math.pi/pts; rr = r if i % 2 == 0 else inner
        o.append((math.cos(a)*rr, math.sin(a)*rr))
    return o
def clear():
    bpy.ops.object.select_all(action="SELECT"); bpy.ops.object.delete(use_global=False)
    for c in (bpy.data.meshes, bpy.data.curves, bpy.data.armatures):
        for b in list(c):
            if b.users == 0: c.remove(b)

# ---------- HERO ----------
def make_hero(ox=0, oy=0):
    R = bpy.data.objects.new("Hero_Root", None); bpy.context.collection.objects.link(R); R.location = (0, 0, 0)
    x0, y0 = ox, oy
    # boots + legs (athletic, not blocky)
    for s, sx in [("L", -.17), ("R", .17)]:
        cube(f"Boot_{s}", (x0+sx, y0-.10, .15), (.135, .24, .115), LEATHER, edge=.06, parent=R)
        cube(f"BootToe_{s}", (x0+sx, y0-.28, .14), (.125, .09, .09), ARMOR_D, edge=.03, parent=R)
        cyl(f"Greave_{s}", (x0+sx, y0, .52), .115, .55, ARMOR, parent=R, v=14)
        cube(f"GreaveStripe_{s}", (x0+sx, y0-.115, .53), (.09, .02, .18), BLUE_L, edge=.01, parent=R)
        ico(f"Knee_{s}", (x0+sx, y0-.12, .83), (.135, .07, .115), ARMOR_L, parent=R)
        cyl(f"Thigh_{s}", (x0+sx, y0, .95), .13, .30, BLUE, parent=R, v=14)
    # tunic + chest (V silhouette)
    cone("Tunic", (x0, y0+.01, 1.12), .42, .30, .70, BLUE, parent=R, v=16)
    cube("TunicHem", (x0, y0-.01, .80), (.32, .24, .06), BLUE_L, edge=.025, parent=R)
    chest = [(-.30,.92),(-.40,1.30),(-.27,1.60),(.27,1.60),(.40,1.30),(.30,.92),(0,.85)]
    plate("Chest", chest, .11, ARMOR, loc=(x0, y0-.27, 0), edge=.035, parent=R)
    inner = [(-.17,1.01),(-.21,1.30),(-.14,1.48),(.14,1.48),(.21,1.30),(.17,1.01),(0,.96)]
    plate("ChestIn", inner, .03, ARMOR_D, loc=(x0, y0-.335, 0), edge=.012, parent=R)
    cube("ChestGem", (x0, y0-.365, 1.29), (.065, .02, .065), GEM, edge=.01, parent=R)
    plate("Crest", star(.12, .05), .025, GOLD, loc=(x0, y0-.385, 1.44), edge=.007, parent=R)
    cube("Belt", (x0, y0-.01, .86), (.40, .27, .06), LEATHER, edge=.02, parent=R)
    cube("Buckle", (x0, y0-.29, .86), (.095, .025, .105), GOLD, edge=.018, parent=R)
    for s, sx in [("L", -.30), ("R", .30)]:
        cube(f"Pouch_{s}", (x0+sx, y0-.24, .81), (.095, .075, .095), LEATHER, edge=.025, parent=R)
    # head + face (heroic happy)
    cyl("Neck", (x0, y0, 1.64), .12, .20, SKIN, parent=R, v=14)
    torus("Collar", (x0, y0, 1.63), .155, .038, ARMOR_D, parent=R)
    sphere("Head", (x0, y0, 1.93), (.27, .24, .305), SKIN, parent=R)
    sphere("Chin", (x0, y0-.20, 1.78), (.10, .06, .08), SKIN_SH, parent=R, seg=16)
    for s, sx in [("L", -.105), ("R", .105)]:
        sphere(f"EyeW_{s}", (x0+sx, y0-.242, 1.97), (.058, .025, .062), EYE_W, parent=R, seg=16)
        sphere(f"Iris_{s}", (x0+sx, y0-.265, 1.97), (.028, .012, .034), EYE_D, parent=R, seg=12)
        sphere(f"Hi_{s}", (x0+sx-.012, y0-.272, 1.985), (.010, .006, .012), EYE_W, parent=R, seg=8)
        cube(f"Brow_{s}", (x0+sx, y0-.266, 2.055), (.068, .012, .017), HAIR, rot=(0, 0, -.14 if s=="L" else .14), edge=.008, parent=R)
        sphere(f"Ear_{s}", (x0+(-.285 if s=="L" else .285), y0, 1.93), (.05, .06, .075), SKIN, parent=R, seg=12)
        sphere(f"Blush_{s}", (x0+sx*1.6, y0-.225, 1.87), (.05, .02, .04), SKIN_SH, parent=R, seg=12)
    sphere("Nose", (x0, y0-.265, 1.905), (.034, .03, .05), SKIN_SH, parent=R, seg=12)
    cube("Smile", (x0, y0-.26, 1.815), (.075, .012, .014), HAIR, edge=.006, parent=R)
    sphere("HairCap", (x0, y0+.01, 2.13), (.295, .26, .175), HAIR, parent=R)
    for i, (hx, hz) in enumerate([(-.22,2.14),(-.12,2.17),(-.01,2.18),(.10,2.17),(.20,2.14)]):
        cone(f"Lock_{i}", (x0+hx, y0-.20, hz), .075, .03, .18, HAIR_HI, rot=(math.radians(10), 0, math.radians(hx*40)), parent=R, v=10)
    sphere("TopKnot", (x0, y0+.16, 2.22), (.09, .09, .10), HAIR, parent=R, seg=14)
    ico("Clasp", (x0, y0+.20, 2.20), (.055, .03, .055), GOLD, parent=R)
    # arms
    for s, sgn in [("L", -1), ("R", 1)]:
        xx = x0 + .44*sgn
        ico(f"Pauldron_{s}", (xx, y0, 1.45), (.20, .19, .15), ARMOR_L, parent=R)
        ico(f"PauldronTrim_{s}", (xx, y0, 1.36), (.205, .195, .06), GOLD, parent=R)
        cyl(f"Sleeve_{s}", (x0+.46*sgn, y0, 1.20), .105, .36, BLUE, rot=(0, sgn*math.radians(12), 0), parent=R, v=14)
        cyl(f"Bracer_{s}", (x0+.51*sgn, y0-.015, .93), .118, .36, ARMOR, rot=(0, sgn*math.radians(9), 0), parent=R, v=14)
        cube(f"BracerGold_{s}", (x0+.51*sgn, y0-.11, .93), (.035, .02, .13), GOLD, edge=.008, parent=R)
        sphere(f"Hand_{s}", (x0+.53*sgn, y0-.02, .72), (.115, .10, .12), SKIN, parent=R, seg=16)
    # shield (heater, left hand)
    shx = x0-.80
    out10 = [(-.52,.34),(-.32,.55),(0,.62),(.32,.55),(.52,.34),(.48,-.22),(.23,-.62),(0,-.82),(-.23,-.62),(-.48,-.22)]
    plate("ShieldBase", out10, .13, ARMOR_D, loc=(shx, y0-.17, 1.05), edge=.035, parent=R)
    inn = [(-.44,.31),(-.27,.48),(0,.53),(.27,.48),(.44,.31),(.40,-.18),(.19,-.52),(0,-.68),(-.19,-.52),(-.40,-.18)]
    plate("ShieldFace", inn, .05, BLUE, loc=(shx, y0-.26, 1.05), edge=.018, parent=R)
    rim = [(-.48,.33),(-.29,.52),(0,.58),(.29,.52),(.48,.33),(.44,-.20),(.21,-.58),(0,-.76),(-.21,-.58),(-.44,-.20)]
    plate("ShieldRim", rim, .028, GOLD, loc=(shx, y0-.30, 1.05), edge=.012, parent=R)
    plate("ShieldStar", star(.23, .095), .035, GOLD, loc=(shx, y0-.335, 1.08), edge=.008, parent=R)
    ico("ShieldGem", (shx, y0-.365, 1.06), (.07, .025, .07), GEM, parent=R)
    cyl("Grip", (x0-.53, y0-.02, 1.05), .045, .40, LEATHER, rot=(0, math.pi/2, 0), parent=R, v=10)
    # spear (right hand, diagonal heroic)
    between("Shaft", (x0+.38, y0-.22, .95), (x0+1.50, y0-.22, 1.58), .035, WOOD, parent=R)
    between("GripW", (x0+.39, y0-.22, .96), (x0+.75, y0-.22, 1.16), .052, LEATHER, parent=R)
    between("Guard", (x0+.72, y0-.22, 1.14), (x0+.78, y0-.22, 1.18), .095, GOLD, parent=R, v=10)
    between("Guard2", (x0+.80, y0-.22, 1.19), (x0+.84, y0-.22, 1.21), .07, ARMOR_D, parent=R, v=10)
    a = Vector((x0+.38, y0-.22, .95)); b = Vector((x0+1.50, y0-.22, 1.58)); d = (b-a).normalized()
    tip_c = b + d*.22; tip = b + d*.45
    sp = cone("SpearHead", (b+tip)/2, .15, 0, .46, STEEL, rot=d.to_track_quat("Z","Y").to_euler(), parent=R, v=8)
    cone("Fuller", b+d*.20, .055, 0, .26, BLUE_L, rot=d.to_track_quat("Z","Y").to_euler(), parent=R, v=6)
    # cape (readable silhouette from behind)
    verts = [(-.34,.22,1.60),(.34,.22,1.60),(.64,.27,.60),(.40,.28,.46),(0,.30,.40),(-.40,.28,.46),(-.64,.27,.60)]
    me = bpy.data.meshes.new("Cape_M"); me.from_pydata([(v[0]+x0, v[1]+y0, v[2]) for v in verts], [], [(0,1,2,3,4,5,6)]); me.update()
    cape = bpy.data.objects.new("Cape", me); bpy.context.collection.objects.link(cape); cape.parent = R
    cape.data.materials.append(BLUE); bevel(cape, .02, 2)
    sol = cape.modifiers.new("Thick", "SOLIDIFY"); sol.thickness = .04
    between("TrimL", (x0-.35, y0+.25, 1.59), (x0, y0+.31, .42), .018, GOLD, parent=R, v=8)
    between("TrimR", (x0+.35, y0+.25, 1.59), (x0, y0+.31, .42), .018, GOLD, parent=R, v=8)
    ico("ClaspL", (x0-.18, y0-.01, 1.59), (.06,.06,.06), GOLD, parent=R)
    ico("ClaspR", (x0+.18, y0-.01, 1.59), (.06,.06,.06), GOLD, parent=R)
    return R

# ---------- ENEMY (faceless white monkey) ----------
def make_enemy(ox=3.4, oy=0):
    R = bpy.data.objects.new("Enemy_Root", None); bpy.context.collection.objects.link(R); R.location = (0, 0, 0)
    x0, y0 = ox, oy
    # hunched torso leaning forward (+Y is forward? use Y forward)
    sphere("E_Torso", (x0, y0+.10, 1.05), (.38, .30, .55), ENEMY, parent=R, seg=20)
    sphere("E_Belly", (x0, y0-.12, .95), (.30, .20, .42), ENEMY_D, parent=R, seg=18)
    sphere("E_Hump", (x0, y0+.30, 1.38), (.32, .26, .30), ENEMY, parent=R, seg=18)
    sphere("E_Head", (x0, y0+.38, 1.62), (.26, .24, .24), ENEMY, parent=R, seg=20)
    # NO face — faceless as spec. Add subtle brow ridge + skull crease only
    cube("E_Brow", (x0, y0+.585, 1.66), (.30, .04, .06), ENEMY_D, edge=.02, parent=R)
    for s, sx in [("L", -.15), ("R", .15)]:
        # long arms for knuckle-walk, bent
        between(f"E_UpperArm_{s}", (x0+sx*1.8, y0+.10, 1.30), (x0+sx*2.6, y0+.30, .85), .105, ENEMY, parent=R)
        between(f"E_ForeArm_{s}", (x0+sx*2.6, y0+.30, .85), (x0+sx*2.7, y0+.42, .30), .09, ENEMY, parent=R)
        sphere(f"E_Knuckle_{s}", (x0+sx*2.7, y0+.42, .24), (.13, .13, .10), ENEMY_D, parent=R, seg=14)
        # 3 claws per hand
        for i, off in enumerate([-.08, 0, .08]):
            cone(f"E_Claw_{s}{i}", (x0+sx*2.7+off, y0+.55, .14), .035, 0, .22, ENEMY_CLAW, rot=(math.radians(100), 0, 0), parent=R, v=8)
        # short bent legs
        between(f"E_Thigh_{s}", (x0+sx, y0+.05, .70), (x0+sx*1.2, y0-.10, .40), .115, ENEMY, parent=R)
        between(f"E_Shin_{s}", (x0+sx*1.2, y0-.10, .40), (x0+sx*1.2, y0+.05, .12), .095, ENEMY, parent=R)
        cube(f"E_Foot_{s}", (x0+sx*1.2, y0+.12, .09), (.12, .22, .08), ENEMY_D, edge=.03, parent=R)
        for i, off in enumerate([-.06, 0, .06]):
            cone(f"E_Toe_{s}{i}", (x0+sx*1.2+off, y0+.26, .07), .028, 0, .14, ENEMY_CLAW, rot=(math.radians(90), 0, 0), parent=R, v=8)
    # back spikes (small, readable at distance)
    for i, z in enumerate([1.45, 1.25, 1.05]):
        cone(f"E_Spike_{i}", (x0, y0+.48, z), .07, 0, .18, ENEMY_D, rot=(math.radians(-30), 0, 0), parent=R, v=7)
    # shoulder + hip joints bulk
    for s, sx in [("L", -.34), ("R", .34)]:
        sphere(f"E_Sholder_{s}", (x0+sx, y0+.10, 1.30), (.15, .14, .15), ENEMY, parent=R, seg=14)
    return R

# ---------- ENVIRONMENT ----------
def make_env():
    E = bpy.data.objects.new("Env_Root", None); bpy.context.collection.objects.link(E)
    # hill: wide cylinder, top slightly domed by scaling + extra ring
    bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=9, depth=1.4, location=(0, 0, -.7))
    hill = bpy.context.object; hill.name = "Hill"; hill.parent = E
    hill.data.materials.append(HILL); smooth(hill)
    # spawn ring (darker torus flat on hill)
    torus("SpawnRing", (0, 0, .02), 7.5, .12, HILL_D, parent=E)
    # center plaza (flat light disc where walls stand)
    cyl("Plaza", (0, 0, .01), 5.8, .10, WALLM, parent=E, v=48)
    # rocks + grass tufts outside walls
    import random
    random.seed(7)
    for i in range(10):
        a = random.uniform(0, math.pi*2); r = random.uniform(6.2, 8.6)
        rx, ry = math.cos(a)*r, math.sin(a)*r
        s = random.uniform(.12, .30)
        ico(f"Rock_{i}", (rx, ry, .08), (s, s*.8, s*.7), ROCK, parent=E, subd=1)
    for i in range(16):
        a = random.uniform(0, math.pi*2); r = random.uniform(5.5, 8.8)
        rx, ry = math.cos(a)*r, math.sin(a)*r
        cone(f"Grass_{i}", (rx, ry, .18), .09, .01, .35, GRASS, parent=E, v=6)
    # four walls, walkable top (player can stand), enemy passes through gate gaps
    # wall length 10, height .95, thickness .45, at +-5
    wall_defs = [("Wall_N", (0, 5.0, .48), (5.2, .45, .48)), ("Wall_S", (0, -5.0, .48), (5.2, .45, .48)),
                 ("Wall_E", (5.0, 0, .48), (.45, 5.2, .48)), ("Wall_W", (-5.0, 0, .48), (.45, 5.2, .48))]
    for n, loc, sc in wall_defs:
        cube(n, loc, sc, WALLM, edge=.06, parent=E)
        # cap (walkable, blue tint)
        if "N" in n or "S" in n:
            cube(n+"_Cap", (loc[0], loc[1], .99), (5.45, .62, .09), WALL_CAP, edge=.03, parent=E)
        else:
            cube(n+"_Cap", (loc[0], loc[1], .99), (.62, 5.45, .09), WALL_CAP, edge=.03, parent=E)
    # corner towers + pyramid roofs
    for cx, cy in [(5, 5), (5, -5), (-5, 5), (-5, -5)]:
        cube(f"Tower_{cx}_{cy}", (cx, cy, .75), (.70, .70, .75), WALLM, edge=.07, parent=E)
        cube(f"TowerCap_{cx}_{cy}", (cx, cy, 1.55), (.82, .82, .10), WALL_CAP, edge=.03, parent=E)
        cone(f"Roof_{cx}_{cy}", (cx, cy, 1.95), .62, 0, .60, BLUE, parent=E, v=4)
    # gate gaps visual: two gold posts per side
    for gx, gy, rot in [(0, 5.0, 0), (0, -5.0, 0), (5.0, 0, 1), (-5.0, 0, 1)]:
        for off in (-1.1, 1.1):
            px = gx + (off if rot == 0 else 0); py = gy + (0 if rot == 0 else off)
            cyl(f"GatePost_{gx}_{gy}_{off}", (px, py, .65), .09, 1.1, GOLD, parent=E, v=10)
            ico(f"GateOrb_{gx}_{gy}_{off}", (px, py, 1.28), (.11, .11, .11), GEM, parent=E)
    return E

# ---------- RIG + ANIM ----------
def add_bone(eb, n, h, t, p=None):
    b = eb.new(n); b.head = h; b.tail = t
    if p: b.parent = eb.get(p)
    return b
def build_hero_rig():
    data = bpy.data.armatures.new("EpicHeroArm"); arm = bpy.data.objects.new("EpicHeroRig", data)
    bpy.context.collection.objects.link(arm)
    bpy.context.view_layer.objects.active = arm; arm.select_set(True); bpy.ops.object.mode_set(mode="EDIT")
    e = data.edit_bones
    add_bone(e, "root", (0,0,0), (0,0,.8))
    add_bone(e, "spine", (0,0,.72), (0,0,1.62), "root")
    add_bone(e, "head", (0,0,1.60), (0,0,2.30), "spine")
    for s, x in [("L",-.17),("R",.17)]:
        add_bone(e, "thigh."+s, (x,0,.85), (x,0,.50), "root")
        add_bone(e, "shin."+s, (x,0,.50), (x,0,.16), "thigh."+s)
        add_bone(e, "foot."+s, (x,0,.16), (x,-.22,.12), "shin."+s)
    for s, x in [("L",-.40),("R",.40)]:
        add_bone(e, "upper_arm."+s, (x,0,1.45), (x*1.25,0,1.18), "spine")
        add_bone(e, "forearm."+s, (x*1.25,0,1.18), (x*1.30,0,.90), "upper_arm."+s)
        add_bone(e, "hand."+s, (x*1.30,0,.90), (x*1.30,0,.70), "forearm."+s)
    bpy.ops.object.mode_set(mode="OBJECT"); arm.show_in_front = True
    def attach(o, b):
        if not data.bones.get(b): return
        w = o.matrix_world.copy(); o.parent = arm; o.parent_type = "BONE"; o.parent_bone = b; o.matrix_world = w
    for o in list(bpy.data.objects):
        if o.type != "MESH": continue
        n = o.name; b = "spine"
        if any(k in n for k in ["Head","Hair","Eye","Iris","Brow","Ear","Blush","Nose","Smile","Chin","Hi_","Lock","TopKnot","Clasp"]): b = "head"
        elif n.startswith("Boot_") or "Toe" in n: b = "foot.L" if "_L" in n or n.endswith("_L") else "foot.R" if "_R" in n or n.endswith("_R") else "spine"
        elif "Greave" in n or "Knee" in n or "Thigh" in n: b = "thigh.L" if "_L" in n or "L" in n[-2:] else "thigh.R" if "_R" in n or "R" in n[-2:] else "spine"
        elif "Shield" in n or "Grip" == n: b = "hand.L"
        elif "Spear" in n or "Shaft" in n or "Guard" in n or "Fuller" in n: b = "hand.R"
        elif n.endswith("_L") and any(k in n for k in ["Pauldron","Sleeve"]): b = "upper_arm.L"
        elif n.endswith("_R") and any(k in n for k in ["Pauldron","Sleeve"]): b = "upper_arm.R"
        elif n.endswith("_L"): b = "forearm.L"
        elif n.endswith("_R"): b = "forearm.R"
        attach(o, b)
    return arm

def make_action(arm, name, frames):
    a = bpy.data.actions.new(name); a.use_fake_user = True
    arm.animation_data_create(); arm.animation_data.action = a
    bones = ["spine","head","thigh.L","shin.L","foot.L","thigh.R","shin.R","foot.R","upper_arm.L","forearm.L","hand.L","upper_arm.R","forearm.R","hand.R"]
    for fr, poses in frames:
        for n in bones:
            p = arm.pose.bones.get(n)
            if p: p.rotation_mode = "XYZ"; p.rotation_euler = (0,0,0)
        for n, rot in poses.items():
            p = arm.pose.bones.get(n)
            if p: p.rotation_mode = "XYZ"; p.rotation_euler = rot; p.keyframe_insert("rotation_euler", frame=fr, group=n)
        arm.pose.bones["root"].keyframe_insert("location", frame=fr, group="root")
    for fc in a.fcurves:
        for kp in fc.keyframe_points: kp.interpolation = "BEZIER"
    return a
def animate_hero(arm):
    r = math.radians
    idle = make_action(arm, "Hero_Idle", [(1,{}),(20,{"spine":(0,r(1.5),0),"head":(0,r(-1.5),0)}),(40,{})])
    make_action(arm, "Hero_Walk", [(1,{"thigh.L":(r(26),0,0),"thigh.R":(r(-26),0,0),"upper_arm.L":(r(-20),0,0),"upper_arm.R":(r(20),0,0)}),(11,{}),(21,{"thigh.L":(r(-26),0,0),"thigh.R":(r(26),0,0),"upper_arm.L":(r(20),0,0),"upper_arm.R":(r(-20),0,0)}),(31,{}),(41,{"thigh.L":(r(26),0,0),"thigh.R":(r(-26),0,0),"upper_arm.L":(r(-20),0,0),"upper_arm.R":(r(20),0,0)})])
    make_action(arm, "Hero_Attack", [(1,{"upper_arm.R":(0,r(-35),r(18)),"forearm.R":(r(-30),0,0),"spine":(0,r(-8),0)}),(8,{"upper_arm.R":(0,r(28),r(-18)),"forearm.R":(r(24),0,0),"spine":(0,r(8),0)}),(15,{"upper_arm.R":(0,r(46),r(-22)),"forearm.R":(r(40),0,0)}),(25,{})])
    make_action(arm, "Hero_Block", [(1,{"upper_arm.L":(r(-35),0,r(-50)),"forearm.L":(r(-24),0,0),"upper_arm.R":(r(-15),0,r(20))}),(12,{"upper_arm.L":(r(-55),0,r(-68)),"forearm.L":(r(-35),0,0)}),(24,{})])
    arm.animation_data.action = idle

# ---------- RENDER + EXPORT ----------
def setup_light_camera(target=(0,0,1.0)):
    sc = bpy.context.scene; sc.render.engine = "BLENDER_EEVEE"
    sc.render.resolution_x = 900; sc.render.resolution_y = 900; sc.render.resolution_percentage = 100
    sc.render.image_settings.file_format = "PNG"
    for o in list(bpy.data.objects):
        if o.type in ("CAMERA","LIGHT"): bpy.data.objects.remove(o, do_unlink=True)
    bpy.ops.object.camera_add(location=(4.6,-6.4,3.2))
    cam = bpy.context.object; sc.camera = cam
    cam.rotation_euler = (Vector(target)-cam.location).to_track_quat("-Z","Y").to_euler(); cam.data.lens = 55
    for loc, en, sz in [((-3,-4,5.5),1200,4.5),((4,-2,3.5),900,3.5),((0,4,4.5),900,3.5)]:
        bpy.ops.object.light_add(type="AREA", location=loc)
        li = bpy.context.object; li.data.energy = en; li.data.shape = "DISK"; li.data.size = sz
        li.rotation_euler = (Vector(target)-li.location).to_track_quat("-Z","Y").to_euler()
    bpy.ops.object.light_add(type="SUN", location=(2,2,8)); bpy.context.object.data.energy = 1.2
    return cam

clear()
hero = make_hero(0, 0)
enemy = make_enemy(3.4, 0)
env = make_env()
rig = build_hero_rig()
animate_hero(rig)
bpy.ops.wm.save_as_mainfile(filepath=out("gema_epic_set.blend"))

# export FBX (all except cameras/lights)
bpy.ops.object.select_all(action="DESELECT")
for o in bpy.data.objects:
    if o.type in ("MESH","ARMATURE"): o.select_set(True)
bpy.context.view_layer.objects.active = rig
bpy.ops.export_scene.fbx(filepath=out("gema_epic_set.fbx"), use_selection=True, object_types={"ARMATURE","MESH"},
    add_leaf_bones=False, bake_anim=True, bake_anim_use_all_actions=True, apply_scale_options="FBX_SCALE_UNITS")

# previews: hero closeup, enemy closeup, full scene
cam = setup_light_camera((0,0,1.0))
# isolate hero
for o in bpy.data.objects:
    if o.type == "MESH" and (o.name.startswith("E_") or o.name in ("Hill","Plaza","SpawnRing") or o.name.startswith(("Wall","Tower","Roof","Gate","Rock","Grass"))):
        o.hide_render = True
    else: o.hide_render = False
bpy.context.scene.render.filepath = out("gema_epic_hero.png")
bpy.ops.render.render(write_still=True)
# isolate enemy
for o in bpy.data.objects:
    if o.type == "MESH" and (o.name.startswith("E_")): o.hide_render = False
    elif o.type == "MESH": o.hide_render = True
cam.location = (3.4+3.2, -4.5, 2.4)
cam.rotation_euler = (Vector((3.4,0,.9))-cam.location).to_track_quat("-Z","Y").to_euler()
bpy.context.scene.render.filepath = out("gema_epic_enemy.png")
bpy.ops.render.render(write_still=True)
# full scene
for o in bpy.data.objects:
    if o.type == "MESH": o.hide_render = False
enemy.hide_render = False
cam.location = (7.5,-9.5,5.0)
cam.rotation_euler = (Vector((0,0,.6))-cam.location).to_track_quat("-Z","Y").to_euler()
bpy.context.scene.render.filepath = out("gema_epic_scene.png")
bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=out("gema_epic_set.blend"))
print("EPIC SET DONE")
