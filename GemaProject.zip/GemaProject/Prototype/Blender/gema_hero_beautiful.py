import bpy
import math
from mathutils import Vector

# Gema hero redesign: cleaner proportions, stronger silhouette, richer armor,
# decorative shield/spear, cape, rigid-part rig and Unity-ready animations.

def make_mat(name, color, metallic=0.0, roughness=0.5):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1.0)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get('Principled BSDF')
    if bsdf:
        bsdf.inputs['Base Color'].default_value = (*color, 1.0)
        bsdf.inputs['Metallic'].default_value = metallic
        bsdf.inputs['Roughness'].default_value = roughness
        if 'Coat Weight' in bsdf.inputs:
            bsdf.inputs['Coat Weight'].default_value = .25 if metallic else .08
    return m

SKIN = make_mat('Beauty_Skin', (0.78, 0.38, 0.20), 0, .52)
SKIN_LIGHT = make_mat('Beauty_Skin_Light', (0.95, 0.60, 0.40), 0, .48)
HAIR = make_mat('Beauty_Hair', (0.065, 0.018, 0.008), 0, .7)
HAIR_HIGHLIGHT = make_mat('Beauty_Hair_Highlight', (0.22, 0.055, 0.012), 0, .58)
ARMOR = make_mat('Beauty_Armor_Silver', (0.48, 0.61, 0.78), .78, .22)
ARMOR_LIGHT = make_mat('Beauty_Armor_Highlight', (0.78, 0.88, 0.96), .68, .18)
ARMOR_DARK = make_mat('Beauty_Armor_Dark', (0.055, 0.11, 0.20), .72, .22)
BLUE = make_mat('Beauty_Royal_Blue', (0.035, 0.16, 0.52), .12, .32)
BLUE_LIGHT = make_mat('Beauty_Blue_Highlight', (0.10, 0.38, 0.92), .15, .3)
GOLD = make_mat('Beauty_Gold', (0.95, 0.52, 0.07), .82, .18)
LEATHER = make_mat('Beauty_Leather', (0.12, 0.025, 0.008), 0, .74)
WOOD = make_mat('Beauty_Spear_Wood', (0.45, 0.13, 0.025), 0, .55)
WEAPON = make_mat('Beauty_Spear_Steel', (0.50, 0.72, 0.90), .9, .14)
EYE_WHITE = make_mat('Beauty_Eye_White', (0.98, 0.99, 0.98), 0, .2)
EYE_DARK = make_mat('Beauty_Eye_Dark', (0.015, 0.025, 0.055), .1, .12)
GEM = make_mat('Beauty_Gem', (0.08, 0.85, 0.95), .45, .12)

def smooth(obj):
    if hasattr(obj.data, 'polygons'):
        for p in obj.data.polygons:
            p.use_smooth = True
    return obj

def bevel(obj, width=.03, segments=3):
    mod = obj.modifiers.new('Soft_Edges', 'BEVEL')
    mod.width = width; mod.segments = segments
    return obj

def cube(name, loc, scale, mat, rot=(0, 0, 0), edge=.03, parent=None):
    bpy.ops.mesh.primitive_cube_add(location=loc, rotation=rot)
    o = bpy.context.object; o.name = name; o.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    if edge: bevel(o, edge, 3)
    o.data.materials.append(mat)
    if parent: o.parent = parent
    return o

def sphere(name, loc, scale, mat, parent=None, segments=20):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=12, location=loc)
    o = bpy.context.object; o.name = name; o.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    smooth(o); o.data.materials.append(mat)
    if parent: o.parent = parent
    return o

def ico(name, loc, scale, mat, parent=None):
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=2, radius=1, location=loc)
    o = bpy.context.object; o.name = name; o.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    smooth(o); o.data.materials.append(mat)
    if parent: o.parent = parent
    return o

def cylinder(name, loc, radius, depth, mat, rot=(0, 0, 0), parent=None, vertices=16, smooth_faces=True):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=loc, rotation=rot)
    o = bpy.context.object; o.name = name; o.data.materials.append(mat)
    if smooth_faces: smooth(o)
    bevel(o, .015, 2)
    if parent: o.parent = parent
    return o

def cone(name, loc, r1, r2, depth, mat, rot=(0, 0, 0), parent=None, vertices=16):
    bpy.ops.mesh.primitive_cone_add(vertices=vertices, radius1=r1, radius2=r2, depth=depth, location=loc, rotation=rot)
    o = bpy.context.object; o.name = name; o.data.materials.append(mat)
    smooth(o); bevel(o, .012, 2)
    if parent: o.parent = parent
    return o

def torus(name, loc, major, minor, mat, rot=(0, 0, 0), parent=None):
    bpy.ops.mesh.primitive_torus_add(major_radius=major, minor_radius=minor, major_segments=24, minor_segments=8, location=loc, rotation=rot)
    o = bpy.context.object; o.name = name; o.data.materials.append(mat); smooth(o)
    if parent: o.parent = parent
    return o

def extruded_outline(name, outline, y, mat, loc=(0, 0, 0), edge=.025, parent=None):
    n = len(outline); verts=[]
    for x, z in outline: verts.append((x, -y/2, z))
    for x, z in outline: verts.append((x, y/2, z))
    faces=[tuple(range(n-1, -1, -1)), tuple(range(n, 2*n))]
    for i in range(n):
        j=(i+1)%n; faces.append((i,j,n+j,n+i))
    mesh=bpy.data.meshes.new(name+'_Mesh'); mesh.from_pydata(verts, [], faces); mesh.update()
    o=bpy.data.objects.new(name, mesh); bpy.context.collection.objects.link(o); o.location=loc
    o.data.materials.append(mat); bevel(o, edge, 3)
    if parent: o.parent=parent
    return o

def star_outline(radius, inner, points=5, rotation=math.pi/2):
    out=[]
    for i in range(points*2):
        a=rotation+i*math.pi/points; r=radius if i%2==0 else inner
        out.append((math.cos(a)*r, math.sin(a)*r))
    return out

def cylinder_between(name, a, b, radius, mat, parent=None, vertices=14):
    a=Vector(a); b=Vector(b); d=b-a
    o=cylinder(name,(a+b)/2,radius,d.length,mat,parent=parent,vertices=vertices)
    o.rotation_euler=d.to_track_quat('Z','Y').to_euler()
    return o

def clear():
    bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
    for datablocks in (bpy.data.meshes, bpy.data.curves, bpy.data.armatures, bpy.data.cameras, bpy.data.lights):
        for block in list(datablocks):
            if block.users == 0: datablocks.remove(block)

def make_cape(root):
    verts=[(-.33,.22,1.58),(.33,.22,1.58),(.62,.27,.62),(.38,.28,.48),(0,.30,.42),(-.38,.28,.48),(-.62,.27,.62)]
    faces=[tuple(range(7))]
    mesh=bpy.data.meshes.new('Cape_Mesh'); mesh.from_pydata(verts, [], faces); mesh.update()
    o=bpy.data.objects.new('Hero_Cape',mesh); bpy.context.collection.objects.link(o); o.data.materials.append(BLUE); o.parent=root
    solid=o.modifiers.new('Cape_Thickness','SOLIDIFY'); solid.thickness=.035
    bevel(o,.02,2)
    # Gold trim follows the shoulder line and makes the back silhouette readable.
    cylinder_between('Cape_Trim_L',(-.34,.25,1.57),(0,.31,.43),.018,GOLD,parent=root,vertices=8)
    cylinder_between('Cape_Trim_R',(.34,.25,1.57),(0,.31,.43),.018,GOLD,parent=root,vertices=8)

def make_shield(root):
    # A tapered heater shield with a raised face, colored rim and crest.
    outline=[(-.52,.34),(-.32,.55),(0,.62),(.32,.55),(.52,.34),(.48,-.22),(.23,-.62),(0,-.82),(-.23,-.62),(-.48,-.22)]
    extruded_outline('Shield_Base',outline,.13,ARMOR_DARK,loc=(-.78,-.17,1.05),edge=.035,parent=root)
    inner=[(-.44,.31),(-.27,.48),(0,.53),(.27,.48),(.44,.31),(.40,-.18),(.19,-.52),(0,-.68),(-.19,-.52),(-.40,-.18)]
    extruded_outline('Shield_Face',inner,.045,BLUE,loc=(-.78,-.26,1.05),edge=.018,parent=root)
    rim=[(-.48,.33),(-.29,.52),(0,.58),(.29,.52),(.48,.33),(.44,-.20),(.21,-.58),(0,-.76),(-.21,-.58),(-.44,-.20)]
    extruded_outline('Shield_Rim',rim,.025,GOLD,loc=(-.78,-.30,1.05),edge=.012,parent=root)
    crest=star_outline(.23,.095,5,math.pi/2)
    extruded_outline('Shield_Crest',crest,.035,GOLD,loc=(-.78,-.335,1.08),edge=.008,parent=root)
    ico('Shield_Gem',(-.78,-.365,1.06),(.07,.025,.07),GEM,parent=root)
    cylinder('Shield_Grip',(-.53,-.02,1.05),.045,.38,LEATHER,rot=(0,math.pi/2,0),parent=root,vertices=10)

def make_spear(root):
    a=(.38,-.22,.95); b=(1.47,-.22,1.55); d=(Vector(b)-Vector(a)).normalized()
    cylinder_between('Spear_Shaft',a,b,.035,WOOD,parent=root,vertices=12)
    # leather grip and gold guard near the hand
    cylinder_between('Spear_Grip',(.39,-.22,.96),(.73,-.22,1.14),.052,LEATHER,parent=root,vertices=12)
    cylinder_between('Spear_Guard',(.70,-.22,1.13),(.76,-.22,1.17),.095,GOLD,parent=root,vertices=10)
    base=Vector(b); tip=base+d*.40
    spear=cone('Spear_Leaf_Head',(base+tip)/2,.14,0,.40,WEAPON,rot=d.to_track_quat('Z','Y').to_euler(),parent=root,vertices=8)
    # Blue fuller inset gives the spearhead a designed, not generic, appearance.
    inset=cone('Spear_Head_Inset',base+d*.20,.055,0,.23,BLUE_LIGHT,rot=d.to_track_quat('Z','Y').to_euler(),parent=root,vertices=6)

def make_hero():
    root=bpy.data.objects.new('Hero_Boy_Beautiful',None); bpy.context.collection.objects.link(root)
    # Feet, greaves and a more athletic lower-body silhouette.
    for side, x in [('L',-.17),('R',.17)]:
        cube('Boot_'+side,(x,-.10,.16),(.14,.22,.12),LEATHER,edge=.055,parent=root)
        cube('Boot_Cap_'+side,(x,-.29,.20),(.125,.055,.085),ARMOR_LIGHT,edge=.025,parent=root)
        cylinder('Greave_'+side,(x,0,.52),.115,.52,ARMOR,rot=(0,0,0),parent=root,vertices=12)
        cube('Greave_Stripe_'+side,(x,-.115,.53),(.095,.025,.17),BLUE_LIGHT,edge=.012,parent=root)
        ico('Knee_Guard_'+side,(x,-.13,.82),(.14,.07,.12),ARMOR_LIGHT,parent=root)
    # Tunic and layered chest armor.
    cone('Tunic',(0,.015,1.15),.40,.32,.68,BLUE, parent=root,vertices=8)
    cube('Tunic_Hem',(0,-.01,.84),(.30,.23,.055),BLUE_LIGHT,edge=.025,parent=root)
    chest_outline=[(-.30,.94),(-.38,1.31),(-.25,1.58),(.25,1.58),(.38,1.31),(.30,.94),(.0,.87)]
    extruded_outline('Chest_Plate',chest_outline,.10,ARMOR,loc=(0,-.27,0),edge=.035,parent=root)
    front=[(-.17,1.03),(-.21,1.30),(-.14,1.47),(.14,1.47),(.21,1.30),(.17,1.03),(0,.98)]
    extruded_outline('Chest_Inner',front,.025,ARMOR_DARK,loc=(0,-.335,0),edge=.012,parent=root)
    cube('Chest_Gem',(0,-.37,1.29),(.065,.018,.065),GEM,edge=.01,parent=root)
    extruded_outline('Chest_Crest',star_outline(.12,.05,5),.025,GOLD,loc=(0,-.38,1.29),edge=.007,parent=root)
    # Belt, pouches and a bright buckle.
    cube('Belt',(0,-.01,.86),(.39,.26,.055),LEATHER,edge=.02,parent=root)
    cube('Belt_Buckle',(0,-.285,.86),(.09,.025,.10),GOLD,edge=.018,parent=root)
    for side,x in [('L',-.29),('R',.29)]:
        cube('Pouch_'+side,(x,-.25,.82),(.09,.07,.09),LEATHER,edge=.025,parent=root)
    # Neck and face.
    cylinder('Neck',(0,0,1.62),.12,.18,SKIN,parent=root,vertices=14)
    torus('Collar',(0,0,1.61),.15,.035,ARMOR_DARK,parent=root)
    sphere('Head',(0,0,1.91),(.275,.245,.31),SKIN,parent=root)
    sphere('Cheek_L',(-.12,-.235,1.86),(.075,.025,.065),SKIN_LIGHT,parent=root,segments=14)
    sphere('Cheek_R',(.12,-.235,1.86),(.075,.025,.065),SKIN_LIGHT,parent=root,segments=14)
    for side,x in [('L',-.105),('R',.105)]:
        sphere('EyeWhite_'+side,(x,-.244,1.96),(.055,.025,.060),EYE_WHITE,parent=root,segments=14)
        sphere('Iris_'+side,(x,-.267,1.96),(.027,.012,.033),EYE_DARK,parent=root,segments=12)
        cube('Brow_'+side,(x,-.268,2.045),(.065,.012,.016),HAIR,rot=(0,0,(-.12 if side=='L' else .12)),edge=.008,parent=root)
        sphere('Ear_'+side,((-.29 if side=='L' else .29),0,1.92),(.05,.06,.075),SKIN,parent=root,segments=12)
    sphere('Nose',(0,-.267,1.90),(.035,.035,.055),SKIN_LIGHT,parent=root,segments=12)
    cube('Mouth',(0,-.262,1.80),(.06,.012,.012),HAIR,edge=.006,parent=root)
    # Hair cap with separated stylized locks and a small gold clasp.
    sphere('Hair_Cap',(0,.005,2.12),(.295,.26,.18),HAIR,parent=root)
    for i,(x,z,r) in enumerate([(-.23,2.08,.10),(-.13,2.12,.095),(-.03,2.14,.09),(.08,2.13,.095),(.18,2.09,.10)]):
        cone('Hair_Lock_'+str(i),(x,-.225,z),r,.035,.25,HAIR_HIGHLIGHT,rot=(math.radians(8),0,math.radians(x*12)),parent=root,vertices=10)
    ico('Hair_Clasp',(0,.19,2.18),(.06,.025,.06),GOLD,parent=root)
    # Arms, pauldrons and articulated-looking bracers.
    for side,sgn in [('L',-1),('R',1)]:
        x=.43*sgn
        ico('Pauldron_'+side,(x,0,1.43),(.19,.18,.14),ARMOR_LIGHT,parent=root)
        torus('Pauldron_Ring_'+side,(x,0,1.42),.12,.018,GOLD,rot=(0,math.radians(90),0),parent=root)
        cylinder('Sleeve_'+side,(.45*sgn,0,1.20),.105,.35,BLUE,rot=(0,sgn*math.radians(12),0),parent=root,vertices=12)
        cylinder('Bracer_'+side,(.50*sgn,-.015,.94),.115,.34,ARMOR,rot=(0,sgn*math.radians(9),0),parent=root,vertices=12)
        cube('Bracer_Stripe_'+side,(.50*sgn,-.11,.94),(.035,.018,.12),GOLD,edge=.008,parent=root)
        sphere('Hand_'+side,(.52*sgn,-.02,.73),(.115,.10,.12),SKIN,parent=root,segments=14)
    make_shield(root); make_spear(root); make_cape(root)
    return root

def make_turntable():
    bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=2.15, depth=.10, location=(0,0,-.07))
    o=bpy.context.object; o.name='Beauty_Pedestal'; o.data.materials.append(ARMOR_DARK); bevel(o,.04,3)

def add_bone(ebones,name,head,tail,parent=None):
    b=ebones.new(name); b.head=head; b.tail=tail
    if parent: b.parent=ebones.get(parent)
    return b

def build_rig():
    data=bpy.data.armatures.new('Beauty_Hero_Armature'); arm=bpy.data.objects.new('Beauty_Hero_Rig',data); bpy.context.collection.objects.link(arm)
    bpy.context.view_layer.objects.active=arm; arm.select_set(True); bpy.ops.object.mode_set(mode='EDIT')
    e=data.edit_bones
    add_bone(e,'root',(0,0,0),(0,0,.8)); add_bone(e,'spine',(0,0,.72),(0,0,1.62),'root'); add_bone(e,'head',(0,0,1.60),(0,0,2.28),'spine')
    for s,x in [('L',-.17),('R',.17)]:
        add_bone(e,'thigh.'+s,(x,0,.82),(x,0,.48),'root'); add_bone(e,'shin.'+s,(x,0,.48),(x,0,.16),'thigh.'+s); add_bone(e,'foot.'+s,(x,0,.16),(x,-.20,.12),'shin.'+s)
    for s,x in [('L',-.38),('R',.38)]:
        add_bone(e,'upper_arm.'+s,(x,0,1.43),(x*1.28,0,1.18),'spine'); add_bone(e,'forearm.'+s,(x*1.28,0,1.18),(x*1.30,0,.90),'upper_arm.'+s); add_bone(e,'hand.'+s,(x*1.30,0,.90),(x*1.30,0,.70),'forearm.'+s)
    bpy.ops.object.mode_set(mode='OBJECT'); arm.show_in_front=True
    def attach(o,bone):
        if not data.bones.get(bone): return
        w=o.matrix_world.copy(); o.parent=arm; o.parent_type='BONE'; o.parent_bone=bone; o.matrix_world=w
    for o in list(bpy.data.objects):
        if o.type!='MESH' or o.name=='Beauty_Pedestal': continue
        n=o.name; b='spine'
        if any(k in n for k in ['Head','Hair','Eye','Iris','Brow','Ear','Cheek','Nose','Mouth']): b='head'
        elif n.endswith('_L') and any(k in n for k in ['Boot','Greave','Knee']): b='shin.L'
        elif n.endswith('_R') and any(k in n for k in ['Boot','Greave','Knee']): b='shin.R'
        elif 'Shield' in n: b='hand.L'
        elif 'Spear' in n: b='hand.R'
        elif n.endswith('_L') and any(k in n for k in ['Pauldron','Sleeve']): b='upper_arm.L'
        elif n.endswith('_R') and any(k in n for k in ['Pauldron','Sleeve']): b='upper_arm.R'
        elif n.endswith('_L'): b='forearm.L'
        elif n.endswith('_R'): b='forearm.R'
        attach(o,b)
    return arm

def action(arm,name,frames):
    a=bpy.data.actions.new(name); a.use_fake_user=True; arm.animation_data_create(); arm.animation_data.action=a
    bone_names=['spine','head','thigh.L','shin.L','foot.L','thigh.R','shin.R','foot.R','upper_arm.L','forearm.L','hand.L','upper_arm.R','forearm.R','hand.R']
    for frame,poses in frames:
        for n in bone_names:
            p=arm.pose.bones.get(n)
            if p: p.rotation_mode='XYZ'; p.rotation_euler=(0,0,0)
        for n,rot in poses.items():
            p=arm.pose.bones.get(n)
            if p: p.rotation_mode='XYZ'; p.rotation_euler=rot; p.keyframe_insert('rotation_euler',frame=frame,group=n)
        arm.pose.bones['root'].keyframe_insert('location',frame=frame,group='root')
    for fc in a.fcurves:
        for kp in fc.keyframe_points: kp.interpolation='BEZIER'
    return a

def make_actions(arm):
    r=math.radians
    idle=action(arm,'Hero_Idle',[(1,{}),(20,{'spine':(0,r(1.5),0),'head':(0,r(-1.5),0)}),(40,{})])
    action(arm,'Hero_Walk',[(1,{'thigh.L':(r(24),0,0),'thigh.R':(r(-24),0,0),'upper_arm.L':(r(-18),0,0),'upper_arm.R':(r(18),0,0)}),(11,{}),(21,{'thigh.L':(r(-24),0,0),'thigh.R':(r(24),0,0),'upper_arm.L':(r(18),0,0),'upper_arm.R':(r(-18),0,0)}),(31,{}),(41,{'thigh.L':(r(24),0,0),'thigh.R':(r(-24),0,0),'upper_arm.L':(r(-18),0,0),'upper_arm.R':(r(18),0,0)})])
    action(arm,'Hero_Attack',[(1,{'upper_arm.R':(0,r(-35),r(18)),'forearm.R':(r(-30),0,0),'spine':(0,r(-8),0)}),(8,{'upper_arm.R':(0,r(28),r(-18)),'forearm.R':(r(24),0,0),'spine':(0,r(8),0)}),(15,{'upper_arm.R':(0,r(46),r(-22)),'forearm.R':(r(40),0,0)}),(25,{})])
    action(arm,'Hero_Block',[(1,{'upper_arm.L':(r(-35),0,r(-50)),'forearm.L':(r(-24),0,0),'upper_arm.R':(r(-15),0,r(20))}),(12,{'upper_arm.L':(r(-52),0,r(-66)),'forearm.L':(r(-35),0,0),'upper_arm.R':(r(-22),0,r(26))}),(24,{})])
    arm.animation_data.action=idle

def export_fbx(arm):
    bpy.ops.object.select_all(action='DESELECT'); arm.select_set(True)
    for o in bpy.data.objects:
        if o.type=='MESH' and o.name!='Beauty_Pedestal': o.select_set(True)
    bpy.context.view_layer.objects.active=arm
    bpy.ops.export_scene.fbx(filepath=bpy.path.abspath('//gema_hero_beautiful.fbx'),use_selection=True,object_types={'ARMATURE','MESH'},add_leaf_bones=False,bake_anim=True,bake_anim_use_all_actions=True,apply_scale_options='FBX_SCALE_UNITS')

clear(); hero=make_hero(); make_turntable(); rig=build_rig(); make_actions(rig); export_fbx(rig)
bpy.ops.wm.save_as_mainfile(filepath=bpy.path.abspath('//gema_hero_beautiful.blend'))
print('Beautiful hero created: redesigned armor, shield, spear, cape, rig, actions and FBX')
