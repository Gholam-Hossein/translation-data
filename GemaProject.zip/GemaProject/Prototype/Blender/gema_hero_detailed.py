import bpy
import math
from mathutils import Vector

# Detailed stylized hero for Gema. Run with Blender 4.1 in background mode.

def material(name, color, metallic=0.0, roughness=0.55):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1.0)
    m.metallic = metallic
    m.roughness = roughness
    return m

SKIN = material('Hero_Skin', (0.78, 0.42, 0.25), 0, .62)
HAIR = material('Hero_Hair', (0.12, 0.035, 0.012), 0, .8)
ARMOR = material('Hero_Armor_Silver', (0.48, 0.58, 0.68), .65, .3)
ARMOR_DARK = material('Hero_Armor_Dark', (0.12, 0.20, 0.30), .7, .27)
BLUE = material('Hero_Blue_Cloth', (0.06, 0.20, 0.55), 0, .48)
GOLD = material('Hero_Gold', (0.82, 0.48, 0.08), .75, .25)
LEATHER = material('Hero_Leather', (0.18, 0.055, 0.018), 0, .8)
EYE = material('Hero_Eyes', (0.025, 0.06, 0.09), 0, .2)
WEAPON = material('Hero_Weapon', (0.42, 0.52, 0.62), .8, .2)

def cube(name, loc, scale, mat, bevel=.03, rot=(0,0,0), parent=None):
    bpy.ops.mesh.primitive_cube_add(location=loc, rotation=rot)
    o=bpy.context.object; o.name=name; o.scale=scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    if bevel:
        b=o.modifiers.new('Rounded_Edges','BEVEL'); b.width=bevel; b.segments=3
    o.data.materials.append(mat)
    if parent: o.parent=parent
    return o

def sphere(name, loc, scale, mat, parent=None, segments=16):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=10, location=loc)
    o=bpy.context.object; o.name=name; o.scale=scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    o.data.materials.append(mat)
    if parent: o.parent=parent
    return o

def cyl(name, loc, radius, depth, mat, rot=(0,0,0), parent=None, vertices=12):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=loc, rotation=rot)
    o=bpy.context.object; o.name=name; o.data.materials.append(mat)
    if parent: o.parent=parent
    return o

def clear():
    bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)

def make_hero():
    root=bpy.data.objects.new('Hero_Boy_Detailed',None); bpy.context.collection.objects.link(root)
    # Feet and legs
    for side in (-1,1):
        x=side*.18
        cyl('Leg_Armor_'+str(side),(x,0,.53),.115,.72,ARMOR, parent=root)
        cube('Boot_'+str(side),(x,-.09,.16),(.16,.29,.15),LEATHER,.06,parent=root)
        cube('Knee_'+str(side),(x,-.10,.83),(.14,.06,.12),ARMOR_DARK,.025,parent=root)
    # Tunic, torso armor and waist
    cube('Blue_Tunic',(0,.02,1.06),(.38,.25,.43),BLUE,.08,parent=root)
    cube('Chest_Plate',(0,-.245,1.22),(.34,.045,.31),ARMOR,.045,parent=root)
    cube('Chest_Center',(0,-.292,1.24),(.10,.025,.20),BLUE,.02,parent=root)
    cube('Belt',(0,-.01,.79),(.43,.28,.07),LEATHER,.025,parent=root)
    cube('Belt_Buckle',(0,-.30,.80),(.09,.035,.09),GOLD,.02,parent=root)
    # Neck and head
    cyl('Neck',(0,0,1.63),.13,.18,SKIN,parent=root)
    sphere('Head',(0,0,1.91),(.30,.27,.34),SKIN,parent=root)
    # Hair cap + fringe
    sphere('HairCap',(0,.015,2.12),(.31,.28,.17),HAIR,parent=root)
    for i,x in enumerate((-.22,-.11,0,.11,.22)):
        sphere('Hair_Fring_'+str(i),(x,-.245,2.06-(abs(x)*.15)),(.08,.055,.12),HAIR,parent=root,segments=12)
    # Ears, eyes, brows, nose and smile
    for side in (-1,1):
        sphere('Ear_'+str(side),(side*.30,0,1.94),(.055,.07,.09),SKIN,parent=root,segments=12)
        sphere('Eye_'+str(side),(side*.105,-.258,1.96),(.038,.018,.045),EYE,parent=root,segments=12)
        cube('Brow_'+str(side),(side*.105,-.275,2.045),(.065,.015,.018),HAIR,.01,rot=(0,side*.10,side*.12),parent=root)
    sphere('Nose',(0,-.275,1.90),(.035,.025,.055),SKIN,parent=root,segments=12)
    cube('Smile',(0,-.272,1.82),(.065,.012,.012),HAIR,.006,parent=root)
    # Arms, gauntlets and shoulder pads
    for side in (-1,1):
        x=side*.52
        sphere('Shoulder_Pad_'+str(side),(x,0,1.38),(.18,.24,.15),ARMOR,parent=root)
        cyl('Upper_Arm_'+str(side),(side*.48,0,1.18),.105,.42,BLUE,rot=(0,side*.18,0),parent=root)
        cyl('Forearm_Guard_'+str(side),(side*.50,-.01,.91),.13,.36,ARMOR,rot=(0,side*.12,0),parent=root)
        sphere('Hand_'+str(side),(side*.51,-.02,.68),(.13,.11,.13),SKIN,parent=root)
        cube('Cuff_'+str(side),(side*.50,-.02,.77),(.14,.13,.05),ARMOR_DARK,.02,parent=root)
    # Shield on left arm, layered construction
    cyl('Shield_Core',(-.72,-.16,1.02),.39,.09,ARMOR_DARK,rot=(math.pi/2,0,0),parent=root,vertices=16)
    cyl('Shield_Face',(-.72,-.215,1.02),.33,.035,BLUE,rot=(math.pi/2,0,0),parent=root,vertices=16)
    cyl('Shield_Rim',(-.72,-.245,1.02),.36,.025,GOLD,rot=(math.pi/2,0,0),parent=root,vertices=16)
    cube('Shield_Cross_V',(-.72,-.272,1.02),(.035,.02,.27),GOLD,.01,parent=root)
    cube('Shield_Cross_H',(-.72,-.273,1.02),(.27,.02,.035),GOLD,.01,parent=root)
    # Spear with grip, guard, shaft and pointed tip
    cyl('Spear_Shaft',(.78,-.02,1.25),.035,1.9,LEATHER,rot=(0,math.pi/2,0),parent=root,vertices=10)
    cyl('Spear_Grip',(.52,-.02,1.25),.052,.45,ARMOR_DARK,rot=(0,math.pi/2,0),parent=root,vertices=10)
    cyl('Spear_Guard',(.98,-.02,1.25),.10,.035,GOLD,rot=(0,math.pi/2,0),parent=root,vertices=10)
    bpy.ops.mesh.primitive_cone_add(vertices=8, radius1=.11, radius2=0, depth=.40, location=(1.96,-.02,1.25), rotation=(0,math.pi/2,0))
    tip=bpy.context.object; tip.name='Spear_Tip'; tip.data.materials.append(WEAPON); tip.parent=root
    # Cape and collar make the silhouette readable from the back and side.
    mesh=bpy.data.meshes.new('Cape_Mesh')
    mesh.from_pydata([(-.44,.20,1.56),(.44,.20,1.56),(.58,.22,.58),(-.58,.22,.58)], [], [(0,1,2,3)])
    mesh.update()
    cape=bpy.data.objects.new('Hero_Cape',mesh); bpy.context.collection.objects.link(cape); cape.parent=root; cape.data.materials.append(BLUE)
    solid=cape.modifiers.new('Cape_Thickness','SOLIDIFY'); solid.thickness=.035
    bevel=cape.modifiers.new('Cape_Soft_Edge','BEVEL'); bevel.width=.025; bevel.segments=2
    cube('Cape_Clasp_L',(-.18,-.01,1.57),(.065,.065,.065),GOLD,.02,parent=root)
    cube('Cape_Clasp_R',(.18,-.01,1.57),(.065,.065,.065),GOLD,.02,parent=root)
    return root

def make_turntable():
    bpy.ops.mesh.primitive_cylinder_add(vertices=48, radius=2.2, depth=.12, location=(0,0,-.08))
    base=bpy.context.object; base.name='Hero_Turntable'; base.data.materials.append(ARMOR_DARK)

def make_bone(ebones, name, head, tail, parent=None):
    b=ebones.new(name); b.head=head; b.tail=tail
    if parent: b.parent=ebones.get(parent)
    return b

def build_rig(hero_root):
    data=bpy.data.armatures.new('Hero_Rig_Armature')
    arm=bpy.data.objects.new('Hero_Rig',data); bpy.context.collection.objects.link(arm)
    bpy.context.view_layer.objects.active=arm; arm.select_set(True)
    bpy.ops.object.mode_set(mode='EDIT')
    e=data.edit_bones
    make_bone(e,'root',(0,0,0),(0,0,.8))
    make_bone(e,'spine',(0,0,.72),(0,0,1.62),'root')
    make_bone(e,'head',(0,0,1.58),(0,0,2.25),'spine')
    make_bone(e,'thigh.L',(-.18,0,.80),(-.18,0,.45),'root')
    make_bone(e,'shin.L',(-.18,0,.45),(-.18,0,.16),'thigh.L')
    make_bone(e,'foot.L',(-.18,0,.16),(-.18,-.20,.12),'shin.L')
    make_bone(e,'thigh.R',(.18,0,.80),(.18,0,.45),'root')
    make_bone(e,'shin.R',(.18,0,.45),(.18,0,.16),'thigh.R')
    make_bone(e,'foot.R',(.18,0,.16),(.18,-.20,.12),'shin.R')
    make_bone(e,'upper_arm.L',(-.34,0,1.42),(-.52,0,1.18),'spine')
    make_bone(e,'forearm.L',(-.52,0,1.18),(-.52,0,.86),'upper_arm.L')
    make_bone(e,'hand.L',(-.52,0,.86),(-.52,0,.68),'forearm.L')
    make_bone(e,'upper_arm.R',(.34,0,1.42),(.50,0,1.18),'spine')
    make_bone(e,'forearm.R',(.50,0,1.18),(.50,0,.86),'upper_arm.R')
    make_bone(e,'hand.R',(.50,0,.86),(.50,0,.68),'forearm.R')
    bpy.ops.object.mode_set(mode='OBJECT')
    arm.show_in_front=True

    # Rigid-part parenting keeps the stylized armor pieces crisp while still exporting a usable skeleton.
    def assign(obj, bone):
        world=obj.matrix_world.copy(); obj.parent=arm; obj.parent_type='BONE'; obj.parent_bone=bone; obj.matrix_world=world
    for obj in list(bpy.data.objects):
        if obj.type != 'MESH' or obj.name == 'Hero_Turntable': continue
        n=obj.name
        bone=None
        if any(k in n for k in ['Head','Hair','Ear','Eye','Brow','Nose','Smile']): bone='head'
        elif any(k in n for k in ['Leg_Armor_-1','Knee_-1']): bone='thigh.L'
        elif n == 'Boot_-1': bone='foot.L'
        elif any(k in n for k in ['Leg_Armor_1','Knee_1']): bone='thigh.R'
        elif n == 'Boot_1': bone='foot.R'
        elif n.endswith('_-1') or any(k in n for k in ['Shield']): bone='hand.L'
        elif n.endswith('_1'): bone='hand.R'
        elif any(k in n for k in ['Spear']): bone='hand.R'
        elif any(k in n for k in ['Upper_Arm']): bone='upper_arm.L' if n.endswith('_-1') else 'upper_arm.R'
        elif any(k in n for k in ['Forearm','Hand','Cuff']): bone='forearm.L' if n.endswith('_-1') else 'forearm.R'
        elif any(k in n for k in ['Shoulder']): bone='upper_arm.L' if n.endswith('_-1') else 'upper_arm.R'
        elif any(k in n for k in ['Cape','Chest','Tunic','Belt','Clasp','Neck']): bone='spine'
        if bone and data.bones.get(bone): assign(obj,bone)
    return arm

def key_pose(action, arm, frames):
    action=bpy.data.actions.new(action); action.use_fake_user=True
    arm.animation_data_create(); arm.animation_data.action=action
    bones=['spine','head','thigh.L','shin.L','foot.L','thigh.R','shin.R','foot.R','upper_arm.L','forearm.L','hand.L','upper_arm.R','forearm.R','hand.R']
    for frame, poses in frames:
        for b in bones:
            pb=arm.pose.bones.get(b)
            if not pb: continue
            pb.rotation_mode='XYZ'; pb.rotation_euler=(0,0,0)
        for name, rot in poses.items():
            pb=arm.pose.bones.get(name)
            if pb:
                pb.rotation_mode='XYZ'; pb.rotation_euler=rot; pb.keyframe_insert('rotation_euler',frame=frame,group=name)
        arm.pose.bones['root'].keyframe_insert('location',frame=frame,group='root')
    for fc in action.fcurves:
        for kp in fc.keyframe_points: kp.interpolation='BEZIER'
    return action

def make_animations(arm):
    r=math.radians
    idle=key_pose('Hero_Idle',arm,[(1,{}),(20,{'spine':(0,r(1),0),'head':(0,r(-1),0)}),(40,{})])
    walk=key_pose('Hero_Walk',arm,[(1,{'thigh.L':(r(25),0,0),'thigh.R':(r(-25),0,0),'upper_arm.L':(r(-22),0,0),'upper_arm.R':(r(22),0,0)}),(11,{}),(21,{'thigh.L':(r(-25),0,0),'thigh.R':(r(25),0,0),'upper_arm.L':(r(22),0,0),'upper_arm.R':(r(-22),0,0)}),(31,{}),(41,{'thigh.L':(r(25),0,0),'thigh.R':(r(-25),0,0),'upper_arm.L':(r(-22),0,0),'upper_arm.R':(r(22),0,0)})])
    attack=key_pose('Hero_Attack',arm,[(1,{'upper_arm.R':(0,r(-35),r(20)),'forearm.R':(r(-35),0,0),'spine':(0,r(-8),0)}),(8,{'upper_arm.R':(0,r(35),r(-15)),'forearm.R':(r(25),0,0),'spine':(0,r(10),0)}),(14,{'upper_arm.R':(0,r(50),r(-20)),'forearm.R':(r(45),0,0)}),(24,{})])
    block=key_pose('Hero_Block',arm,[(1,{'upper_arm.L':(r(-35),0,r(-50)),'forearm.L':(r(-25),0,0),'upper_arm.R':(r(-20),0,r(20))}),(12,{'upper_arm.L':(r(-55),0,r(-65)),'forearm.L':(r(-35),0,0),'upper_arm.R':(r(-25),0,r(25))}),(24,{})])
    arm.animation_data.action=idle
    return [idle,walk,attack,block]

def export_unity(arm):
    bpy.ops.object.select_all(action='DESELECT')
    arm.select_set(True)
    for obj in bpy.data.objects:
        if obj.type == 'MESH' and obj.name != 'Hero_Turntable': obj.select_set(True)
    bpy.context.view_layer.objects.active=arm
    bpy.ops.export_scene.fbx(filepath=bpy.path.abspath('//gema_hero_unity.fbx'), use_selection=True, object_types={'ARMATURE','MESH'}, add_leaf_bones=False, bake_anim=True, bake_anim_use_all_actions=True, apply_scale_options='FBX_SCALE_UNITS')

clear(); hero=make_hero(); make_turntable(); rig=build_rig(hero); make_animations(rig); export_unity(rig)
bpy.ops.wm.save_as_mainfile(filepath=bpy.path.abspath('//gema_hero_complete.blend'))
print('Complete hero created: rig + Idle + Walk + Attack + Block + Unity FBX')
