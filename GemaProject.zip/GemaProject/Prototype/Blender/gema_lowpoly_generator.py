import bpy
import math
from mathutils import Vector

# Run in Blender 4.1. Creates simple blockout assets for the Gema prototype.

def mat(name, color):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1.0)
    return m

BLUE = mat('Armor_Blue', (0.16, 0.35, 0.72))
SILVER = mat('Armor_Silver', (0.65, 0.72, 0.78))
BROWN = mat('Hair_Brown', (0.20, 0.08, 0.03))
WHITE = mat('Enemy_White', (0.88, 0.90, 0.86))
GREEN = mat('Hill_Green', (0.16, 0.48, 0.15))
WALL = mat('Wall_PinkBlue', (0.72, 0.78, 0.92))
METAL = mat('Weapon_Metal', (0.55, 0.60, 0.66))

def cube(name, loc, scale, material, bevel=0.0):
    bpy.ops.mesh.primitive_cube_add(location=loc)
    o = bpy.context.object; o.name = name; o.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    if bevel:
        mod = o.modifiers.new('SoftEdges', 'BEVEL'); mod.width = bevel; mod.segments = 2
    o.data.materials.append(material); return o

def uv(name, loc, scale, material, segments=12):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=8, location=loc)
    o = bpy.context.object; o.name = name; o.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    o.data.materials.append(material); return o

def cylinder(name, loc, radius, depth, material, rotation=(0,0,0), vertices=10):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=loc, rotation=rotation)
    o = bpy.context.object; o.name=name; o.data.materials.append(material); return o

def clear():
    bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)

def make_player(origin=(0,0,0)):
    x,y,z = origin
    root = bpy.data.objects.new('Player_Blockout', None); bpy.context.collection.objects.link(root)
    parts = [cube('Body',(x,y,z+1.05),(.34,.22,.48),SILVER,.06), uv('Head',(x,y,z+1.75),(.27,.24,.28),SILVER), cube('Hair',(x,y-.01,z+1.98),(.25,.22,.10),BROWN,.03), cube('Chest_Blue',(x,y-.23,z+1.15),(.25,.03,.27),BLUE,.02)]
    parts += [cylinder('Leg_L',(x-.16,y,z+.45),.10,.55,SILVER), cylinder('Leg_R',(x+.16,y,z+.45),.10,.55,SILVER)]
    for p in parts: p.parent=root
    cylinder('Spear',(x+.63,y,z+1.15),.025,1.9,METAL,rotation=(0,math.pi/2,0),vertices=8).parent=root
    cylinder('Shield',(x-.42,y-.15,z+1.0),.36,.08,BLUE,rotation=(math.pi/2,0,0),vertices=12).parent=root
    return root

def make_enemy(origin=(0,0,0)):
    x,y,z=origin; root=bpy.data.objects.new('Enemy_Blockout',None); bpy.context.collection.objects.link(root)
    parts=[uv('Enemy_Body',(x,y,z+1.0),(.36,.25,.55),WHITE), uv('Enemy_Head',(x,y,z+1.7),(.28,.25,.25),WHITE)]
    for side in (-1,1):
        parts.append(cylinder('Enemy_Arm',(x+side*.43,y,z+1.15),.09,.85,WHITE,rotation=(0,side*.75,0)))
        parts.append(cylinder('Enemy_Leg',(x+side*.16,y,z+.42),.11,.75,WHITE,rotation=(0,side*.25,0)))
    for p in parts: p.parent=root
    return root

def make_environment():
    bpy.ops.mesh.primitive_cylinder_add(vertices=32, radius=7, depth=1.2, location=(0,0,-.6)); hill=bpy.context.object; hill.name='Hill'; hill.scale.z=.8; hill.data.materials.append(GREEN)
    for name, loc, scale in [('Wall_N',(0,5.0,.35),(5,.25,.35)),('Wall_S',(0,-5.0,.35),(5,.25,.35)),('Wall_E',(5,0,.35),(.25,5,.35)),('Wall_W',(-5,0,.35),(.25,5,.35))]: cube(name,loc,scale,WALL,.08)

clear(); make_player(); make_enemy((2,0,0)); make_environment()
bpy.ops.wm.save_as_mainfile(filepath=bpy.path.abspath('//gema_blockout.blend'))
print('Gema blockout created: player, enemy, hill, walls, spear, shield')
