import bpy
from mathutils import Vector

scene=bpy.context.scene
scene.render.engine='BLENDER_EEVEE'
scene.render.resolution_x=700; scene.render.resolution_y=700; scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'
scene.render.filepath='//gema_hero_preview.png'

bpy.ops.object.camera_add(location=(4.4,-6.2,3.0))
cam=bpy.context.object; scene.camera=cam
target=Vector((0,0,1.05)); cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
cam.data.lens=58

for loc, energy, size in [((-3,-4,5),1100,4.0),((4,-2,3),800,3.0),((0,4,4),900,3.0)]:
    bpy.ops.object.light_add(type='AREA', location=loc)
    light=bpy.context.object; light.data.energy=energy; light.data.shape='DISK'; light.data.size=size
    light.rotation_euler=(target-light.location).to_track_quat('-Z','Y').to_euler()

bpy.ops.object.light_add(type='AREA', location=(0,0,6))
top=bpy.context.object; top.data.energy=500; top.data.size=5
top.rotation_euler=(0,0,0)
bpy.ops.wm.save_as_mainfile(filepath='//gema_hero_detailed.blend')
bpy.ops.render.render(write_still=True)
