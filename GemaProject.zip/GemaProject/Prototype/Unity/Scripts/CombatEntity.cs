using UnityEngine;

public class CombatEntity : MonoBehaviour
{
    public float maxHealth = 100f;
    public float health;
    public bool IsDead => health <= 0f;

    void Awake() => health = maxHealth;

    public virtual void TakeDamage(float amount)
    {
        if (IsDead) return;
        health = Mathf.Max(0f, health - amount);
        if (IsDead) Die();
    }

    protected virtual void Die() { Destroy(gameObject); }
}
