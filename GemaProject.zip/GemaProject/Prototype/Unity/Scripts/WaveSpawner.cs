using UnityEngine;

public class WaveSpawner : MonoBehaviour
{
    public EnemyAI enemyPrefab;
    public Transform player;
    public int totalEnemies = 100;
    public float radius = 7f;
    public float spawnInterval = .25f;
    int spawned;
    float nextSpawn;

    void Update()
    {
        if (!enemyPrefab || spawned >= totalEnemies || Time.time < nextSpawn) return;
        nextSpawn = Time.time + spawnInterval;
        float a = spawned * 2.399963f;
        Vector3 center = player ? player.position : transform.position;
        Vector3 pos = center + new Vector3(Mathf.Cos(a), 0, Mathf.Sin(a)) * radius;
        Instantiate(enemyPrefab, pos, Quaternion.identity);
        spawned++;
    }
}
