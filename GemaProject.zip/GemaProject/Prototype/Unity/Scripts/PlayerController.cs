using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerController : CombatEntity
{
    public float moveSpeed = 4f;
    public float attackRange = 1.7f;
    public float attackDamage = 25f;
    public float blockMultiplier = .2f;
    public Transform attackPoint;
    CharacterController controller;
    bool blocking;
    int attackType;

    void Start() { controller = GetComponent<CharacterController>(); }

    void Update()
    {
        Vector3 input = new Vector3(Input.GetAxisRaw("Horizontal"), 0, Input.GetAxisRaw("Vertical"));
        if (input.sqrMagnitude > 1) input.Normalize();
        controller.SimpleMove(input * moveSpeed);
        if (input.sqrMagnitude > .01f) transform.forward = input;
        blocking = Input.GetKey(KeyCode.Space);
        if (Input.GetKeyDown(KeyCode.J)) { attackType = 1; Attack(); }
        if (Input.GetKeyDown(KeyCode.K)) { attackType = 2; Attack(); }
        if (Input.GetKeyDown(KeyCode.L)) { attackType = 3; Attack(); }
    }

    void Attack()
    {
        float damage = attackDamage * (attackType == 3 ? 1.8f : 1f);
        Collider[] hits = Physics.OverlapSphere(attackPoint ? attackPoint.position : transform.position + transform.forward, attackRange);
        foreach (Collider hit in hits)
            if (hit.TryGetComponent<EnemyAI>(out var enemy)) enemy.TakeDamage(damage);
    }

    public override void TakeDamage(float amount) => base.TakeDamage(blocking ? amount * blockMultiplier : amount);
}
