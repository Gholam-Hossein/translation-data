using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
public class EnemyAI : CombatEntity
{
    public float attackDistance = 1.35f;
    public float attackCooldown = 1.2f;
    public float attackDamage = 10f;
    Transform target;
    NavMeshAgent agent;
    float nextAttack;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        var player = FindObjectOfType<PlayerController>();
        if (player) target = player.transform;
    }

    void Update()
    {
        if (!target || IsDead) return;
        float distance = Vector3.Distance(transform.position, target.position);
        if (distance > attackDistance) agent.SetDestination(target.position);
        else { agent.ResetPath(); transform.LookAt(new Vector3(target.position.x, transform.position.y, target.position.z)); if (Time.time >= nextAttack) { nextAttack = Time.time + attackCooldown; target.GetComponent<PlayerController>()?.TakeDamage(attackDamage); } }
    }
}
